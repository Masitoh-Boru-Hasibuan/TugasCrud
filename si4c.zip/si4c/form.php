<form action="insert.php" method="post">
nim : <br>
<input type="text" name="nim" id="">
<br>
nama : <br>
<input type="text" name="nama" id="">
<br>
alamat : <br>
<input type="text" name="alamat" id="">
<br>
jkl : <br>
<select name="jkl" id="">
<option value="pria">pria</option>
<option value="wanita">wanita</option>
</select>
<br>
agama : <br>
<select name="agama" id="">
<option value="islam">islam</option>
<option value="kristen">kristen</option>
</select>
<br>
email : <br>
<input type="text" name="email" id="">
<br>
pwd : <br>
<input type="text" name="pwd" id="">
<br>
<button type="submit">Simpan mahasiswa</button>
</form>