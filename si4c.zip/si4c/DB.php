<?php
$koneksi=mysqli_connect('localhost','root','','db_perpustakaan4c')or die('Database tidak ditemukan');
//jalankan uri: localhost/si4c/DB.php
//jika tampilan kosong,artinya koneksi berhasil
?>