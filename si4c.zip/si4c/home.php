<div class="row">
<div class="col-lg-12 col-sm-12">
    <div class="alert alert-info">
        <strong>welcome to Smart Library</strong>
        <p>Sistem informasi manajemen perpustakaan berbasis AI</p>
</div>
</div>
</div>