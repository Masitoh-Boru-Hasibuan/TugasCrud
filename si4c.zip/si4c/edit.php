<!-- Mengambil data yang akan diedit, berdasarkan nim yang dipilih dan
dikirim melalui link (get) -->
2. <?php
3. $nim=$_GET['nim'];
4. //membuat sql tampil data
5. $sqldata="SELECT * FROM tblmhsw WHERE nim='$nim'";
6. //ambil koneksi data
7. require_once "KoneksiDB.php";
8. //proses sql
9. $query=mysqli_query($koneksi,$sqldata);
10. //mengubah data ke array asosiatif, tidak menggunakan perulangan karena
datanya hanya 1.
11. $data=mysqli_fetch_assoc($query);
12. //selanjutnya tampilkan pada field dibawah.
13. ?>
14. <h2>Update Data Mahasiswa</h2>
15. <!-- tag form -->
16. <form action="Update.php" method="POST">
17. <label>Nomor Induk Mahasiswa :</label>
18. <input type="text" name="nim" value="<?=$data['nim']?>"
placeholder="Nomor Induk Mahasiswa" required>
19. <br>
20. <label>Nama Mahasiswa :</label>
21. <input type="text" name="nama" id="nama" value="<?=$data['name']?>"
placeholder="Nama Lengkap" required>
22. <br>
23. <label for="">Alamat :</label>
24. <input type="text" name="alamat" id="alamat"
value="<?=$data['address']?>" placeholder="Alamat Lengkap" required>
25. <br>
26. <label for="">Program Studi :</label>
27. <select name="prodi" id="prodi">