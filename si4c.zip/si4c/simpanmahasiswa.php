<?php
//include koneksi
include "DB.php";
//buat sql
$sql="INSERT INTO mahasiswa (nim,nama,alamat,jkl,agama,email,pwd,creat_at,updated_at) VALUES ('5679', 'putri', 'plasmen', 'WANITA', 'islam', 'putri@gmail.com', '223344', current_timestamp(), '2024-04-22 05:34:53.00000')";
$q=mysqli_query($koneksi,$sql)or die('SQL error');
if($q){
    echo "Data berhasil disimpan";
    }else{
        echo "Gagal menyimpan data!" . mysql_error();
    }
    ?>