<?php 
//php case sensitive
$nama="Mas"; // string
$umur=25;
$tinggi=170;
$ipk=3.75; // Double
$status=true; //Logika
//output
echo "Nama : $nama <br>";
echo "Umur : $umur <br>";
echo "Tinggi : $tinggi <br>";
echo "Ipk : $ipk <br>";
echo "Status : $status <br>";
?>